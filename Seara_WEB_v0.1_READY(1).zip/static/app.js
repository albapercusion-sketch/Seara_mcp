const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const landing=$('#landing'), app=$('#app'), demo=$('#demo'), modal=$('#loginModal');
const messages=$('#messages'), composer=$('#composer'), input=$('#message'), file=$('#file'), fileName=$('#fileName');
const MONTHLY_LIMIT=40, HISTORY_TTL=48*60*60*1000;
let history=[];
function monthKey(){const d=new Date();return `seara_count_${d.getFullYear()}_${d.getMonth()+1}`}
function count(){return +(localStorage.getItem(monthKey())||0)}
function bump(){localStorage.setItem(monthKey(),count()+1); updateQuota()}
function updateQuota(){$('#quotaText').textContent=`${count()} / ${MONTHLY_LIMIT}`}
function saveHistory(){localStorage.setItem('seara_history',JSON.stringify({ts:Date.now(),messages:history}))}
function loadHistory(){try{const x=JSON.parse(localStorage.getItem('seara_history')||'null');if(x&&Date.now()-x.ts<HISTORY_TTL){history=x.messages||[]}else localStorage.removeItem('seara_history')}catch{} renderHistory()}
function renderHistory(){messages.innerHTML=''; if(!history.length){messages.innerHTML=`<div class="welcome"><h2>Como podo axudarte?</h2><p>Podes describir un caso, preguntar por normativa, pedir unha intervención ou revisar unha proposta.</p><div class="chips"><button>Analiza este caso educativo</button><button>Deseña unha intervención viable</button><button>Comproba se esta norma segue vixente</button></div></div>`; bindChips();return} history.forEach(addToDOM)}
function addToDOM(m){const wrap=document.createElement('div');wrap.className=`msg ${m.role}`;const b=document.createElement('div');b.className='bubble';b.textContent=m.text;wrap.appendChild(b);messages.appendChild(wrap);messages.scrollTop=messages.scrollHeight}
function add(role,text){const m={role,text,ts:Date.now()};history.push(m);addToDOM(m);saveHistory()}
function bindChips(){$$('.chips button').forEach(b=>b.onclick=()=>{input.value=b.textContent;input.focus()})}
async function session(){try{return (await fetch('/api/session')).json()}catch{return {authenticated:false}}}
function showApp(){landing.classList.add('hidden');demo.classList.add('hidden');app.classList.remove('hidden');loadHistory();updateQuota()}
$('#enterBtn').onclick=async()=>{const s=await session();s.authenticated?showApp():modal.classList.remove('hidden')}
$('#closeLogin').onclick=()=>modal.classList.add('hidden');
$('#loginBtn').onclick=async()=>{const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:$('#code').value})}); if(r.ok){modal.classList.add('hidden');showApp()} else $('#loginError').textContent=(await r.json()).detail||'Non se puido acceder'}
$('#demoBtn').onclick=()=>{landing.classList.add('hidden');demo.classList.remove('hidden')}; $('#backDemo').onclick=()=>{demo.classList.add('hidden');landing.classList.remove('hidden')}
$('#logout').onclick=async()=>{await fetch('/api/logout',{method:'POST'});app.classList.add('hidden');landing.classList.remove('hidden')}
$('#newChat').onclick=()=>{history=[];localStorage.removeItem('seara_history');renderHistory()}
file.onchange=()=>fileName.textContent=file.files[0]?.name||'';
composer.onsubmit=async e=>{e.preventDefault();const text=input.value.trim(); if(!text)return;if(count()>=MONTHLY_LIMIT){alert('Acadaches o límite provisional de 40 consultas deste mes.');return} const f=file.files[0];add('user',text);input.value='';file.value='';fileName.textContent='';const loading={role:'assistant',text:'Consultando…'};addToDOM(loading);const fd=new FormData();fd.append('message',text);fd.append('language','auto');if(f)fd.append('file',f);try{const r=await fetch('/api/chat',{method:'POST',body:fd});const j=await r.json();loading.text=r.ok?j.answer:(j.detail||'Erro inesperado');messages.lastElementChild.querySelector('.bubble').textContent=loading.text;if(r.ok){history.push({role:'assistant',text:loading.text,ts:Date.now()});saveHistory();bump()}}catch{messages.lastElementChild.querySelector('.bubble').textContent='Non foi posible conectar co servidor.'}}
$$('.mode').forEach(b=>b.onclick=()=>{$$('.mode').forEach(x=>x.classList.remove('active'));b.classList.add('active');const g=$('#guided');if(b.dataset.mode==='guided'){messages.classList.add('hidden');g.classList.remove('hidden')}else{g.classList.add('hidden');messages.classList.remove('hidden')}})
$('#useGuided').onclick=()=>{const parts=[`Etapa e curso: ${$('#gStage').value}`,`Situación: ${$('#gSituation').value}`,`Barreiras observadas: ${$('#gBarriers').value}`,`Apoios e recursos dispoñibles: ${$('#gResources').value}`];input.value=`Analiza este caso educativo e propón o seguinte paso máis axeitado.\n\n${parts.join('\n')}`;$('.mode[data-mode="chat"]').click();input.focus()}
$('#exportWord').onclick=async()=>{const r=await fetch('/api/export/word',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:'Consulta Seara IA',messages:history})});if(!r.ok)return alert('Non se puido xerar o Word');const blob=await r.blob();const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='seara_consulta.docx';a.click();URL.revokeObjectURL(a.href)}
$('#printPdf').onclick=()=>window.print();
input.addEventListener('input',()=>{input.style.height='auto';input.style.height=Math.min(input.scrollHeight,130)+'px'});bindChips();updateQuota();
