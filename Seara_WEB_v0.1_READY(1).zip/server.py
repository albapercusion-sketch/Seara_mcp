import os, base64, hmac, hashlib, time, io, re
from fastapi import FastAPI, Request, Form, UploadFile, File, HTTPException
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from openai import OpenAI
from docx import Document

app = FastAPI(title='Seara IA Web', version='0.1.0')
app.mount('/static', StaticFiles(directory='static'), name='static')

ACCESS_CODE = os.getenv('PILOT_ACCESS_CODE','').strip()
SESSION_SECRET = os.getenv('SESSION_SECRET','change-me-in-render').encode()
MODEL = os.getenv('OPENAI_MODEL','gpt-6-luna')
MCP_URL = os.getenv('SEARA_MCP_URL','https://seara-legislative-watch.onrender.com/mcp')
MAX_UPLOAD_MB = 8

SYSTEM = '''Eres Seara IA, asistente educativo para profesorado y especialmente profesionales de orientación, PT y AL en Galicia. Ayudas a analizar casos, diseñar intervenciones, adaptar materiales, revisar propuestas, aplicar DUA y entender normativa. No sustituyes la decisión profesional.

Principios globales: 1 contexto antes que etiqueta; 2 datos antes que certeza; 3 barreras antes que déficit; 4 acceso antes que simplificación innecesaria; 5 viabilidad antes que idealización; 6 autonomía antes que dependencia del apoyo; 7 generalización antes que éxito aislado; 8 evidencia antes que complacencia; 9 trazabilidad antes que autoridad aparente; 10 supervisión humana antes que decisión automática.

Jerarquía: normativa vigente > documentos/protocolos oficiales > marcos pedagógicos/evidencia > protocolos internos de Seara. Distingue siempre qué es obligatorio/prohibido, qué es permitido/posible, qué requiere valoración del centro/equipo y qué es propuesta pedagógica. Si faltan datos, usa semáforo: verde (suficiente), ámbar (orientación provisional + pocas preguntas prioritarias), rojo (no concluir; indicar qué falta y siguiente paso competente). Separa hechos, interpretación e hipótesis. Si hay restricciones claras, ofrece una intervención mínima viable.

Cuando la consulta afecte a vigencia normativa, cambios recientes o protocolos oficiales, utiliza la herramienta MCP disponible y cita la fuente oficial en la respuesta. Para familias, estructura cuando proceda: qué dice la fuente oficial / qué significa / qué podéis preguntar o solicitar / fuente. Responde por defecto en el idioma del usuario. Pide anonimizar datos personales de alumnado y no solicites información identificativa innecesaria.'''

NORMATIVE_RE = re.compile(r'\b(vigente|vigencia|normativ|decreto|orde|orden|dog|lex|protocolo|xunta|lei|ley|resoluci[oó]n|cambio|actualiz|derog|curr[ií]culo|avaliaci[oó]n|evaluaci[oó]n)\b', re.I)

def sign_session(ts: int) -> str:
    msg = str(ts).encode()
    sig = hmac.new(SESSION_SECRET, msg, hashlib.sha256).hexdigest()
    return f'{ts}.{sig}'

def valid_session(token: str|None) -> bool:
    if not token or '.' not in token: return False
    try:
        ts_s, sig = token.split('.',1); ts=int(ts_s)
    except Exception: return False
    if time.time()-ts > 60*60*24*30: return False
    expected=hmac.new(SESSION_SECRET, ts_s.encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(sig, expected)

def require_auth(req: Request):
    if not valid_session(req.cookies.get('seara_session')):
        raise HTTPException(401,'Acceso piloto no autorizado')

@app.get('/')
def index(): return FileResponse('static/index.html')

@app.get('/health')
def health():
    return {'status':'ok','version':'0.1.0','openai_configured': bool(os.getenv('OPENAI_API_KEY')),'model':MODEL,'mcp':MCP_URL}

@app.post('/api/login')
async def login(request: Request):
    data = await request.json(); code=str(data.get('code',''))
    if not ACCESS_CODE:
        raise HTTPException(503,'PILOT_ACCESS_CODE no configurado')
    if not hmac.compare_digest(code, ACCESS_CODE):
        raise HTTPException(401,'Código incorrecto')
    resp=JSONResponse({'ok':True})
    resp.set_cookie('seara_session', sign_session(int(time.time())), httponly=True, secure=True, samesite='lax', max_age=60*60*24*30)
    return resp

@app.post('/api/logout')
def logout():
    r=JSONResponse({'ok':True}); r.delete_cookie('seara_session'); return r

@app.get('/api/session')
def session(request: Request): return {'authenticated': valid_session(request.cookies.get('seara_session'))}

@app.post('/api/chat')
async def chat(request: Request, message: str = Form(...), language: str = Form('auto'), file: UploadFile|None = File(None)):
    require_auth(request)
    if not os.getenv('OPENAI_API_KEY'):
        raise HTTPException(503,'OPENAI_API_KEY no configurada todavía')
    message=message.strip()
    if not message: raise HTTPException(400,'Mensaje vacío')
    content=[{'type':'input_text','text':message}]
    if file and file.filename:
        raw=await file.read()
        if len(raw) > MAX_UPLOAD_MB*1024*1024: raise HTTPException(413,f'Archivo demasiado grande (máx. {MAX_UPLOAD_MB} MB)')
        mime=(file.content_type or 'application/octet-stream').lower()
        b64=base64.b64encode(raw).decode()
        if mime.startswith('image/'):
            content.append({'type':'input_image','image_url':f'data:{mime};base64,{b64}','detail':'auto'})
        else:
            content.append({'type':'input_file','filename':file.filename,'file_data':f'data:{mime};base64,{b64}'})
    tools=[]
    if NORMATIVE_RE.search(message):
        tools=[{'type':'mcp','server_label':'seara_normativa','server_description':'MCP de solo lectura para comprobar normativa y protocolos educativos oficiales de Galicia.','server_url':MCP_URL,'require_approval':'never'}]
    client=OpenAI()
    try:
        resp=client.responses.create(model=MODEL,instructions=SYSTEM,input=[{'role':'user','content':content}],tools=tools,store=False)
        answer=resp.output_text or 'No se ha generado una respuesta textual.'
        return {'answer':answer,'used_live_normative_check':bool(tools),'model':MODEL}
    except Exception as e:
        raise HTTPException(502, f'Error del servicio de IA: {str(e)[:500]}')

@app.post('/api/export/word')
async def export_word(request: Request):
    require_auth(request)
    data=await request.json(); title=data.get('title') or 'Consulta Seara IA'; messages=data.get('messages') or []
    doc=Document(); doc.add_heading(title,0)
    for m in messages:
        role='Consulta' if m.get('role')=='user' else 'Seara IA'
        doc.add_heading(role, level=2); doc.add_paragraph(str(m.get('text','')))
    buf=io.BytesIO(); doc.save(buf); buf.seek(0)
    headers={'Content-Disposition':'attachment; filename="seara_consulta.docx"'}
    return StreamingResponse(buf, media_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document', headers=headers)
