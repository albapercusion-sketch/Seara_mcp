# Seara IA Web v0.1

Piloto web para Seara IA.

## Variables de entorno necesarias
- OPENAI_API_KEY: clave de proyecto de OpenAI (obligatoria para chat real)
- PILOT_ACCESS_CODE: código compartido de acceso al piloto
- SESSION_SECRET: cadena aleatoria larga para firmar la sesión
- OPENAI_MODEL: opcional, por defecto gpt-6-luna
- SEARA_MCP_URL: opcional, por defecto https://seara-legislative-watch.onrender.com/mcp

## Render
Build: `pip install -r requirements.txt`
Start: `uvicorn server:app --host 0.0.0.0 --port $PORT`
Health: `/health`

## Alcance v0.1
- Landing y demo pública ficticia.
- Acceso piloto por código.
- Chat libre + formulario guiado.
- Archivos e imágenes de hasta 8 MB.
- Comprobación normativa en vivo mediante MCP cuando la consulta es normativa.
- Historial local en navegador, caduca a las 48 h.
- Límite mensual provisional de 40 consultas guardado en navegador (no es un control de servidor robusto).
- Exportación Word y opción de impresión/guardar como PDF.

## Pendiente para producción
- Cuentas individuales y base de datos.
- Límite de consultas robusto por usuario.
- Recuperación de contraseña y panel de administración.
- Corpus persistente con File Search/vector store.
- Auditoría de privacidad/RGPD y términos definitivos.
