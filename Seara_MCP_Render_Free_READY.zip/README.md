# Seara Legislative Watch MCP

MCP de solo lectura para mantener Seara IA conectada a fuentes oficiales vivas de Galicia.

## Qué hace
- Comprueba en vivo el estado de la normativa núcleo de Seara.
- Detecta normativa educativa publicada o consolidada recientemente.
- Lee la lista actual de protocolos oficiales de Diversidade e Orientación.
- Ejecuta una revisión combinada y devuelve alertas para revisión humana.

## Fuentes
- DOG RSS oficial (Xunta / Abertos).
- Lex.gal (normativa consolidada y novedades).
- Portal de Diversidade e Orientación de la Xunta.

## Principio de diseño
El MCP aporta evidencia y actualidad. No decide por el docente.
Para familias, el modelo consumidor debe explicar la fuente en lenguaje claro y conservar el enlace oficial.

## Herramientas MCP
- `get_core_legislation_status`
- `get_latest_education_legislation`
- `list_official_education_protocols`
- `check_seara_regulatory_updates`

## Despliegue
Pensado para Streamable HTTP. En producción, el endpoint es `/mcp` y el health check `/health`.

Con Render Blueprint se puede usar `render.yaml`.

## Seguridad y privacidad
- Solo lectura.
- No recibe datos de alumnado.
- No necesita autenticación para consultar información pública.
- No almacena expedientes ni información personal.
- Caché en memoria de 10 minutos para reducir carga sobre fuentes oficiales.

## Nota jurídica
DOG es la fuente oficial primaria. Lex.gal facilita versiones consolidadas, pero sus textos consolidados son informativos y no vinculantes. Para decisiones formales se debe verificar el DOG cuando corresponda.


## Deployment guardrails
- Render compute plan is pinned to `free`.
- The service is read-only and stores no student data.
- Region is set to Frankfurt for the pilot.
- MCP transport: Streamable HTTP at `/mcp`.
- Health check: `/health`.
- No paid Render feature is required by this Blueprint.
