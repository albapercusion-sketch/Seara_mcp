from __future__ import annotations

import asyncio
import os
import re
import time
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urljoin
import xml.etree.ElementTree as ET

import httpx
from bs4 import BeautifulSoup
from mcp.server.mcpserver import MCPServer
from mcp.server.transport_security import TransportSecuritySettings

USER_AGENT = "SearaIA-Legislative-Watch/1.0 (+educational assistant; official sources only)"
TIMEOUT = float(os.getenv("HTTP_TIMEOUT", "20"))
CACHE_SECONDS = int(os.getenv("CACHE_SECONDS", "600"))

DOG_RSS = "https://abertos.xunta.gal/es/catalogo/administracion-publica/-/dataset/0262/actualidad-del-diario-oficial-galicia/001/descarga-directa-del-fichero.rss"
LEX_LATEST = "https://www.lex.gal/ultima-normativa-publicada"
LEX_CONSOLIDATED = "https://www.lex.gal/ultima-normativa-consolidada"
PROTOCOLS = "https://www.edu.xunta.gal/portal/diversidadeorientacion/1764"
LEX_HOME = "https://www.lex.gal/"

CORE_SOURCES = {
    "decreto_229_2011": {
        "title": "Decreto 229/2011, do 7 de decembro, de atención á diversidade",
        "url": "https://www.lex.gal/normativa/detalle/1673?mod=false",
        "type": "normativa",
    },
    "orde_8_9_2021": {
        "title": "Orde do 8 de setembro de 2021 de atención á diversidade",
        "url": "https://www.lex.gal/normativa/detalle/9210?mod=false",
        "type": "normativa",
    },
    "decreto_155_2022": {
        "title": "Decreto 155/2022, do 15 de setembro, currículo de Educación Primaria",
        "url": "https://www.lex.gal/normativa/detalle/8826",
        "type": "curriculo",
    },
    "orde_26_5_2023": {
        "title": "Orde do 26 de maio de 2023, desenvolvemento curricular e avaliación de Primaria",
        "url": "https://www.lex.gal/es/normativa/detalle/9177",
        "type": "curriculo_avaliacion",
    },
    "decreto_150_2022": {
        "title": "Decreto 150/2022, do 8 de setembro, currículo de Educación Infantil",
        "url": "https://www.lex.gal/normativa/detalle/10298",
        "type": "contexto_infantil",
    },
}

EDUCATION_TERMS = (
    "educación", "educacion", "ensino", "ensinanza", "alumnado", "centro docente",
    "profesorado", "currículo", "curriculo", "avaliación", "evaluación", "orientación",
    "diversidade", "inclusión", "inclusion", "pedagoxía terapéutica", "audición e linguaxe",
    "necesidade específica", "nee", "neae", "convivencia", "benestar emocional",
)

_cache: dict[str, tuple[float, Any]] = {}


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _clean(text: str | None) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def _is_education(text: str) -> bool:
    low = text.lower()
    return any(term in low for term in EDUCATION_TERMS)


async def _get_text(url: str) -> tuple[str, int, str]:
    async with httpx.AsyncClient(
        timeout=TIMEOUT,
        follow_redirects=True,
        headers={"User-Agent": USER_AGENT, "Accept-Language": "gl,es;q=0.9"},
    ) as client:
        r = await client.get(url)
        r.raise_for_status()
        return r.text, r.status_code, str(r.url)


async def _cached(key: str, producer):
    entry = _cache.get(key)
    if entry and time.time() - entry[0] < CACHE_SECONDS:
        return entry[1]
    value = await producer()
    _cache[key] = (time.time(), value)
    return value


async def _parse_lex_table(url: str, relevant_only: bool = True) -> list[dict[str, str]]:
    html, _, final_url = await _get_text(url)
    soup = BeautifulSoup(html, "html.parser")
    items: list[dict[str, str]] = []
    for tr in soup.select("table tr"):
        cells = [_clean(td.get_text(" ", strip=True)) for td in tr.find_all(["td", "th"])]
        if len(cells) < 4 or cells[0].lower() in {"disposición", "disposicion"}:
            continue
        link = tr.find("a", href=True)
        title = cells[1] if len(cells) > 1 else ""
        blob = " | ".join(cells)
        if relevant_only and not _is_education(blob):
            continue
        items.append({
            "disposition": cells[0],
            "title": title,
            "status": cells[2] if len(cells) > 2 else "",
            "department": cells[3] if len(cells) > 3 else "",
            "date": cells[4] if len(cells) > 4 else "",
            "url": urljoin(final_url, link["href"]) if link else final_url,
            "source": "Lex.gal",
        })
    return items


async def _parse_protocols() -> list[dict[str, str]]:
    html, _, final_url = await _get_text(PROTOCOLS)
    soup = BeautifulSoup(html, "html.parser")
    items: list[dict[str, str]] = []
    for a in soup.find_all("a", href=True):
        title = _clean(a.get_text(" ", strip=True))
        if not title:
            continue
        low = title.lower()
        if not any(k in low for k in ("protocolo", "guía", "guia", "plan de benestar")):
            continue
        # Search nearby text for a date, without assuming exact Drupal markup.
        parent_text = _clean(a.parent.get_text(" ", strip=True) if a.parent else "")
        m = re.search(r"\b(\d{2}/\d{2}/\d{4})\b", parent_text)
        date = m.group(1) if m else ""
        items.append({
            "title": title,
            "date": date,
            "url": urljoin(final_url, a["href"]),
            "source": "Portal de Diversidade e Orientación — Xunta de Galicia",
            "source_type": "protocolo_oficial",
        })
    # de-duplicate by URL/title
    seen = set()
    out = []
    for item in items:
        key = (item["title"].lower(), item["url"])
        if key not in seen:
            seen.add(key)
            out.append(item)
    return out


async def _parse_dog_rss(limit: int = 100) -> list[dict[str, str]]:
    xml_text, _, final_url = await _get_text(DOG_RSS)
    root = ET.fromstring(xml_text)
    items: list[dict[str, str]] = []
    for item in root.findall(".//item")[:limit]:
        title = _clean(item.findtext("title"))
        desc = _clean(item.findtext("description"))
        link = _clean(item.findtext("link"))
        pub_date = _clean(item.findtext("pubDate"))
        blob = f"{title} {desc}"
        if not _is_education(blob):
            continue
        items.append({
            "title": title,
            "summary": desc[:1000],
            "date": pub_date,
            "url": link or final_url,
            "source": "Diario Oficial de Galicia (RSS oficial)",
            "source_type": "dog_publication",
        })
    return items


async def _verify_core_one(key: str, meta: dict[str, str]) -> dict[str, Any]:
    try:
        html, status_code, final_url = await _get_text(meta["url"])
        soup = BeautifulSoup(html, "html.parser")
        text = _clean(soup.get_text(" ", strip=True))
        status_match = re.search(r"Estado\s*:\s*(En vigor|Derrogada|Derogada|Parcialmente derrogada|Parcialmente derogada|En vacatio legis)", text, re.I)
        dog_match = re.search(r"Publicado en\s*:\s*(DOG\s+\d+\s+\d{2}/\d{2}/\d{4})", text, re.I)
        return {
            "id": key,
            "title": meta["title"],
            "kind": meta["type"],
            "status": status_match.group(1) if status_match else "estado no extraído automáticamente",
            "publication": dog_match.group(1) if dog_match else "",
            "url": final_url,
            "http_status": status_code,
            "verified_at": _now_iso(),
            "source": "Lex.gal (texto consolidado informativo; DOG es la fuente oficial primaria)",
        }
    except Exception as exc:
        return {
            "id": key,
            "title": meta["title"],
            "kind": meta["type"],
            "status": "no verificado",
            "url": meta["url"],
            "verified_at": _now_iso(),
            "error": f"{type(exc).__name__}: {exc}",
        }


mcp = MCPServer(
    "Seara Legislative Watch",
    instructions=(
        "Read-only access to official Galician education sources. Use these tools to verify freshness, "
        "legislative status, newly published rules, and official protocols. Treat DOG as the primary official "
        "source for legal text. Lex.gal is useful for consolidated status but its consolidated versions are "
        "informative rather than legally binding. Preserve teacher professional autonomy: tools provide evidence, "
        "not decisions."
    ),
)


@mcp.tool()
async def get_core_legislation_status() -> dict[str, Any]:
    """Verify the current live status of Seara's core Galician education rules using official/consolidated sources. Read-only."""
    async def produce():
        results = await asyncio.gather(*[_verify_core_one(k, v) for k, v in CORE_SOURCES.items()])
        return {
            "checked_at": _now_iso(),
            "items": results,
            "legal_note": "DOG is the official primary source. Lex.gal consolidated texts are informative and should be cross-checked for formal decisions.",
        }
    return await _cached("core-status", produce)


@mcp.tool()
async def get_latest_education_legislation() -> dict[str, Any]:
    """Return recently published or recently consolidated Galician rules that appear education-related, using live Lex.gal and DOG sources. Read-only."""
    async def produce():
        published, consolidated, dog = await asyncio.gather(
            _parse_lex_table(LEX_LATEST, True),
            _parse_lex_table(LEX_CONSOLIDATED, True),
            _parse_dog_rss(150),
        )
        return {
            "checked_at": _now_iso(),
            "newly_published": published,
            "recently_consolidated": consolidated,
            "dog_recent_matches": dog,
            "sources": [LEX_LATEST, LEX_CONSOLIDATED, DOG_RSS],
            "note": "Keyword filtering is intentionally conservative. A professional should review high-impact changes before converting them into stable Seara rules.",
        }
    return await _cached("latest-legislation", produce)


@mcp.tool()
async def list_official_education_protocols() -> dict[str, Any]:
    """Fetch the current official protocol list from the Xunta de Galicia Diversidade e Orientación portal. Read-only."""
    async def produce():
        items = await _parse_protocols()
        return {
            "checked_at": _now_iso(),
            "items": items,
            "source": PROTOCOLS,
            "note": "This is the live official portal listing. Individual protocol pages/PDFs remain the authoritative source for their content.",
        }
    return await _cached("protocols", produce)


@mcp.tool()
async def check_seara_regulatory_updates() -> dict[str, Any]:
    """Run a live combined surveillance pass over core legislation, recent education-related rules, and the official protocol index. Read-only. Use for update checks and maintenance reviews."""
    core, latest, protocols = await asyncio.gather(
        get_core_legislation_status(),
        get_latest_education_legislation(),
        list_official_education_protocols(),
    )
    flags: list[dict[str, str]] = []
    for item in core.get("items", []):
        status = str(item.get("status", "")).lower()
        if any(k in status for k in ("derrog", "derog", "vacatio", "no verificado")):
            flags.append({"severity": "high", "type": "core_status", "title": item.get("title", ""), "detail": item.get("status", "")})
    if latest.get("newly_published") or latest.get("recently_consolidated") or latest.get("dog_recent_matches"):
        flags.append({"severity": "review", "type": "new_material", "title": "Recent official education-related material detected", "detail": "Review the returned entries for impact on Seara."})
    return {
        "checked_at": _now_iso(),
        "status": "review_needed" if flags else "no_obvious_changes_detected",
        "flags": flags,
        "core": core,
        "latest": latest,
        "protocols": protocols,
        "teacher_autonomy_note": "These findings inform professional judgement; they do not prescribe a single educational decision.",
        "family_communication_note": "When explaining findings to families, cite the official source and translate technical language into clear practical meaning without overstating legal effects.",
    }


@mcp.custom_route("/health", methods=["GET"])
async def health(_request):
    from starlette.responses import JSONResponse
    return JSONResponse({"status": "ok", "service": "seara-legislative-watch", "time": _now_iso()})


app = mcp.streamable_http_app(
    host="0.0.0.0",
    json_response=True,
    stateless_http=True,
    # Render terminates TLS and controls the public Host header at its reverse proxy.
    # Make this choice explicit instead of relying on SDK auto-detection.
    transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=False),
)

if __name__ == "__main__":
    port = int(os.getenv("PORT", "8000"))
    mcp.run(
        transport="streamable-http",
        host="0.0.0.0",
        port=port,
        json_response=True,
        stateless_http=True,
        transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=False),
    )
